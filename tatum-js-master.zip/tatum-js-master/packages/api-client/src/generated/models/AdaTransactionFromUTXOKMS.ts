/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { BtcTransactionFromUTXOKMS } from './BtcTransactionFromUTXOKMS';
import type { FeeAndChange } from './FeeAndChange';

export type AdaTransactionFromUTXOKMS = (FeeAndChange & BtcTransactionFromUTXOKMS);
