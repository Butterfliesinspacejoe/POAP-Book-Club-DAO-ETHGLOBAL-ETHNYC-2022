/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { BtcTransactionFromAddressKMS } from './BtcTransactionFromAddressKMS';
import type { FeeAndChange } from './FeeAndChange';

export type AdaTransactionFromAddressKMS = (FeeAndChange & BtcTransactionFromAddressKMS);
