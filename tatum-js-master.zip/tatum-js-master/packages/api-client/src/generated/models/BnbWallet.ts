/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type BnbWallet = {
    /**
     * Generated account address.
     */
    address?: string;
    /**
     * Generated private key for account.
     */
    privateKey?: string;
}
