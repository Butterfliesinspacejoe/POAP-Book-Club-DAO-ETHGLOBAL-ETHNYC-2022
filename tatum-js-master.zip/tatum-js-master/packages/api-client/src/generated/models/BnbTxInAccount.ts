/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { BnbTransaction } from './BnbTransaction';

export type BnbTxInAccount = {
    total?: number;
    tx?: Array<BnbTransaction>;
}
