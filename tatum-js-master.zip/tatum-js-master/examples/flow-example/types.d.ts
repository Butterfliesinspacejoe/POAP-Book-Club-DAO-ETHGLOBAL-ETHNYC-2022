declare module '@onflow/types'
declare module '@onflow/util-encode-key'
declare module '@onflow/fcl'
