import { terraKmsExample } from './app/terra.kms.example'
import { terraTxExample } from './app/terra.tx.example'
import { terraWalletExample } from './app/terra.wallet.example'

console.log(`Running ${terraKmsExample()}`)
console.log(`Running ${terraTxExample()}`)
console.log(`Running ${terraWalletExample()}`)
