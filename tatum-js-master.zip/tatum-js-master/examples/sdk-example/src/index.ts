/*
import { sdkWalletExample } from './app/sdk.wallet.example'

console.log(`Running ${sdkWalletExample()}`)
*/
